/* Write your data-normalization SQL statements here */
/* Make sure you code your primary keys and foreign keys in SQL (not set up via the GUI) */

drop table if exists SHOW_2NF;
create table SHOW_2NF (
show_id INTEGER,
type_id INTEGER,
title VARCHAR(113),
number_of_featured_countries INTEGER,
release_year INTEGER,
rating VARCHAR(9),
rating_desc VARCHAR(45),
movie_minutes_or_tv_seasons INTEGER,
primary key (show_id)
);
insert into SHOW_2NF select distinct show_id, type_id, title, number_of_featured_countries, release_year, rating, rating_desc, movie_minutes_or_tv_seasons from INTERFLIX_1NF;


drop table if exists PROVIDERINFO_2NF;
create table PROVIDERINFO_2NF (
provider_id INTEGER,
show_id INTEGER,
date_added DATE,
primary key (provider_id, show_id)
foreign key (provider_id) references PROVIDER_3NF(provider_id),
foreign key (show_id) references SHOW_2NF(show_id)
);
insert into PROVIDERINFO_2NF select distinct provider_id, show_id, date_added from INTERFLIX_1NF;


drop table if exists GENRE_AND_SHOW_2NF;
create table GENRE_AND_SHOW_2NF (
show_id INTEGER,
genre_id INTEGER,
primary key(show_id, genre_id)
foreign key (show_id) references SHOW_2NF(show_id)
foreign key (genre_id) references GENRE_3NF(genre_id)
);
insert into GENRE_AND_SHOW_2NF select distinct show_id, genre_id from INTERFLIX_1NF;


drop table if exists RATINGS_3NF;
create table RATINGS_3NF (
rating VARCHAR (9),
rating_desc VARCHAR(45),
primary key (rating)
);
insert into ratings_3NF select distinct rating, rating_desc from SHOW_2NF;


drop table if exists SHOW_3NF;
create table SHOW_3NF (
show_id INTEGER,
type_id INTEGER,
title VARCHAR(113),
number_of_featured_countries INTEGER,
release_year INTEGER,
rating VARCHAR(9),
movie_minutes_or_tv_seasons INTEGER,
primary key (show_id),
foreign key (type_id) references TYPE_3NF(type_id),
foreign key (rating) references RATINGS_3NF(rating)
);
insert into SHOW_3NF select distinct show_id, type_id, title, number_of_featured_countries, release_year, rating, movie_minutes_or_tv_seasons from SHOW_2NF;


drop table if exists PROVIDERINFO_3NF;
create table PROVIDERINFO_3NF (
provider_id INTEGER,
show_id INTEGER,
date_added DATE,
primary key (provider_id, show_id)
foreign key (provider_id) references PROVIDER_3NF(provider_id),
foreign key (show_id) references SHOW_3NF(show_id)
);
insert into PROVIDERINFO_3NF select distinct provider_id, show_id, date_added from PROVIDERINFO_2NF;


drop table if exists GENRE_AND_SHOW_3NF;
create table GENRE_AND_SHOW_3NF (
show_id INTEGER,
genre_id INTEGER,
primary key(show_id, genre_id)
foreign key (show_id) references SHOW_3NF(show_id)
foreign key (genre_id) references GENRE_3NF(genre_id)
);
insert into GENRE_AND_SHOW_3NF select distinct show_id, genre_id from GENRE_AND_SHOW_2NF;


drop table if exists DASHFLIX;
create table DASHFLIX(
title VARCHAR(113),
type_name VARCHAR(7),
genre_label VARCHAR(26),
rating VARCHAR(9),
release_year INTEGER,
movie_minutes_or_tv_seasons INTEGER,
provider_name VARCHAR(12),
number_of_featured_countries INTEGER,
date_added DATE
);


insert into DASHFLIX select distinct SHOW_3NF.title, TYPE_3NF.type_name, GENRE_3NF.genre_label, RATINGS_3NF.rating, SHOW_3NF.release_year, SHOW_3NF.movie_minutes_or_tv_seasons, PROVIDER_3NF.provider_name, SHOW_3NF.number_of_featured_countries, PROVIDERINFO_3NF.date_added
from PROVIDER_3NF, GENRE_3NF, TYPE_3NF, SHOW_3NF, RATINGS_3NF, GENRE_AND_SHOW_3NF, PROVIDERINFO_3NF
where PROVIDER_3NF.provider_id = PROVIDERINFO_3NF.provider_id and SHOW_3NF.show_id = PROVIDERINFO_3NF.show_id and GENRE_3NF.genre_id = GENRE_AND_SHOW_3NF.genre_id and SHOW_3NF.show_id = GENRE_AND_SHOW_3NF.show_id and RATINGS_3NF.rating = SHOW_3NF.rating and TYPE_3NF.type_id = SHOW_3NF.type_id;


